clc;clear;close all;
[lfile,path] = uigetfile('*.*','选择文件夹路径');     
lresult=load([path,lfile]);         

cai(lresult, path,lfile);
% cai(lresult, '_BAol',path,lfile);



%% 感兴趣区域裁剪
function [ ]=cai(lresult, path,lfile)
xu=lfile(1:2);
tifpath=[path,xu,'_Aol.tif'];
[Aol,RAol]=readgeoraster(tifpath);
[rAol,cAol]=size(Aol);
x=double(lresult(:,1));  y=double(lresult(:,2));   z=double(lresult(:,3));  
outfile=[path,lfile(1:length(lfile)-4),'_Aol.txt'];
fidguiao=fopen(outfile,'wt'); 
for i=1:length(x)
    mm=rAol-round((y(i)-RAol.YWorldLimits(1))/RAol.CellExtentInWorldY)+1;
    nn=round((x(i)-RAol.XWorldLimits(1))/RAol.CellExtentInWorldX)+1;
    if (mm<1 || mm>rAol || nn<1 || nn>cAol)
    else
        if Aol(mm, nn)~=Aol(1,1)
            fprintf(fidguiao,'%f\t %f\t %f\t\n',x(i),y(i),z(i));
        end
    end
end
fclose(fidguiao);
end