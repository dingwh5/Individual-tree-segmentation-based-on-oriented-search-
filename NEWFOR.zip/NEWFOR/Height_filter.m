%% 高度概率密度直方图,读入_aol.txt，计算height，对全局切割
clear;clc;close all;
ge=0.2;
[lfile,path] = uigetfile('*.*','选择文件夹路径');     
aol_cloud=load([path,lfile]);  
% aol_cloud=load("F:\NEWFOR\03_Cotolivier\03_ALS_CSFgui_Aol.txt");

aol_x=double(aol_cloud(:,1));  aol_y=double(aol_cloud(:,2));   aol_z=double(aol_cloud(:,3));
max_hang=floor(max(aol_z)/ge)+1;
zhe=zeros(max_hang,1);
for i=1:1:length(aol_x)
    hang=floor(aol_z(i)/ge)+1;
    if hang>0
        zhe(hang,1)=zhe(hang,1)+1;
    end
end

s_zhe = smoothdata(zhe, 'gaussian',7);
dy=diff(s_zhe);
for i=2:1:length(dy)
    if dy(i-1)<0 && dy(i)>0
        Height=(i)*ge;
        break;
    end
end

if Height>3
    Height = 3;
end

outfile=[path,lfile(1:length(lfile)-4),'_',num2str(Height),'.txt'];
fidguiao=fopen(outfile,'wt'); 
for i=1:length(aol_x)
    if aol_z(i)>Height
         fprintf(fidguiao,'%f\t %f\t %f\t \n',aol_x(i),aol_y(i),aol_z(i));
    end
end